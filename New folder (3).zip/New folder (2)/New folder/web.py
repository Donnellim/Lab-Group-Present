from flask import Flask, render_template, request, redirect, url_for

from Link import LinkedList
from Stack import Stack
from Stack import ShuntingYard
from Queue import QueueLinkedList
from Queue import DequeLinkedList

app = Flask(__name__)

# Linked List implementation
linked_list = LinkedList()

@app.route('/')
def index():
    return render_template('web.html')

@app.route('/main')
def main_directory():
    return redirect('/')

@app.route('/linkedlist', methods=['GET', 'POST'])
def LinkedList():
    return render_template('linkedlist.html', elements=linked_list.display())

@app.route('/insert', methods=['POST'])
def insert():
    data = request.form.get('data')
    operation = request.form.get('operation')
    
    if data:
        if operation == 'beginning':
            linked_list.insert_at_beginning(data)
        elif operation == 'end':
            linked_list.insert_at_end(data)
    
    return redirect(url_for('LinkedList'))

@app.route('/remove_beginning', methods=['POST'])
def remove_beginning():
    linked_list.remove_beginning()
    return redirect(url_for('LinkedList'))

@app.route('/remove_at_end', methods=['POST'])
def remove_at_end():
    linked_list.remove_at_end()
    return redirect(url_for('LinkedList'))

@app.route('/remove_at', methods=['POST'])
def remove_at():
    data = request.form.get('data')
    if data:
        linked_list.remove_at(data)
    return redirect(url_for('LinkedList'))

@app.route('/search', methods=['POST'])
def search():
    data_to_search = request.form.get('data')
    search_result = None  # Default search result is None (no search performed)
    searched_data = None  # Default searched data is None (no search term entered)
    
    if data_to_search:  # Perform search only if there is input
        searched_data = data_to_search
        search_result = linked_list.search(data_to_search)

    return render_template(
        'linkedlist.html', 
        elements=linked_list.display(), 
        search_result=search_result, 
        searched_data=searched_data
    )


# Stack implementation
@app.route('/stack_implementation', methods=['GET', 'POST'])
def stack_implementation():
    return render_template('stackimplementation.html', elements=linked_list.display())

@app.route('/convert', methods=['POST'])
def convert():
    infix = request.form.get('infix', '')

    converter = ShuntingYard()
    steps = converter.infix_to_postfix(infix)

    final_answer = steps[-1] if steps else "No steps available"

    return render_template('stackimplementation.html', infix=infix, steps=steps, final_answer=final_answer)


# Queue implementation

# Initialize the queue and deque
queue = QueueLinkedList()
deque = DequeLinkedList()

@app.route('/queue_deque')
def queue_deque_index():
    # Get data for both Queue and Deque
    queue_nodes = queue.display()  # Queue nodes
    deque_nodes = deque.display()  # Deque nodes
    
    return render_template('queue.html', 
                           queue_size=queue.get_size(),
                           queue_front=queue.get_front(),
                           queue_rear=queue.get_rear(),
                           queue_nodes=queue_nodes,  # Pass Queue nodes
                           deque_size=deque.get_size(),
                           deque_front=deque.get_front(),
                           deque_rear=deque.get_rear(),
                           deque_nodes=deque_nodes)  # Pass Deque nodes

# Handling operations for both Queue and Deque (you need routes for these as well)
@app.route('/queue_operation', methods=['POST'])
def queue_operation():
    operation = request.form.get('operation')
    value = request.form.get('value')
    
    if operation == "enqueue":
        queue.enqueue(value)
    elif operation == "dequeue":
        queue.dequeue()
        
    return redirect(url_for('queue_deque_index'))

@app.route('/deque_operation', methods=['POST'])
def deque_operation():
    operation = request.form.get('operation')
    value = request.form.get('value')

    if operation == "add_front":
        deque.add_front(value)
    elif operation == "remove_front":
        deque.remove_front()
    elif operation == "add_rear":
        deque.add_rear(value)
    elif operation == "remove_rear":
        deque.remove_rear()
        
    return redirect(url_for('queue_deque_index'))

if __name__ == "__main__":
    app.run(debug=True)
