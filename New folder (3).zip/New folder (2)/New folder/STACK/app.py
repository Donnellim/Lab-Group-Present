from flask import Flask, render_template, request, redirect, url_for

from Stack import ShuntingYard

app = Flask(__name__)

# Stack implementation
@app.route('/stack_implementation', methods=['GET', 'POST'])
def stack_implementation():
    return render_template('stackimplementation.html', elements=linked_list.display())

@app.route('/convert', methods=['POST'])
def convert():
    infix = request.form.get('infix', '')

    converter = ShuntingYard()
    steps = converter.infix_to_postfix(infix)

    return render_template('stackimplementation.html', infix=infix, steps=steps)
